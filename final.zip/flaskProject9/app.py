from datetime import datetime
from flask import render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import requests

from transformers import AutoModelForQuestionAnswering, AutoTokenizer, pipeline
from flask import Flask, request, jsonify, session

from bs4 import BeautifulSoup

app = Flask(__name__)
app.secret_key = 'whatever'
api_key = "ae4c493816e8413d8ae678b58f47a260"
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:24256802@localhost/SportsNewsDB'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
# Choose the correct pre-trained model
model_name = "distilbert-base-uncased-distilled-squad"
# Load the pre-trained model and tokenizer
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForQuestionAnswering.from_pretrained(model_name)

# Create a pipeline for question-answering
qa_pipeline = pipeline("question-answering", model=model, tokenizer=tokenizer)


class News(db.Model):
    NewsID = db.Column(db.Integer, primary_key=True)
    Title = db.Column(db.String(255))
    Content = db.Column(db.Text)
    Category = db.Column(db.String(100))
    PublishDate = db.Column(db.DateTime)
    Source = db.Column(db.String(255))
    Views = db.Column(db.Integer, default=0)


# Database model for Users
class Users(db.Model):
    UserID = db.Column(db.Integer, primary_key=True)
    Username = db.Column(db.String(100))
    Password = db.Column(db.String(1000))
    Email = db.Column(db.String(500))
    Role = db.Column(db.String(50))
    ProfilePic = db.Column(db.String(255))
    RegisteredDate = db.Column(db.DateTime, default=datetime.utcnow)


# Database model for ChatLogs
class ChatLog(db.Model):
    LogID = db.Column(db.Integer, primary_key=True)
    UserID = db.Column(db.Integer, db.ForeignKey('users.UserID'))
    Message = db.Column(db.Text)
    Timestamp = db.Column(db.DateTime, default=datetime.utcnow)


# Database model for UserRecommendations
class UserRecommendation(db.Model):
    RecommendationID = db.Column(db.Integer, primary_key=True)
    UserID = db.Column(db.Integer, db.ForeignKey('users.UserID'))
    NewsID = db.Column(db.Integer, db.ForeignKey('news.NewsID'))
    Score = db.Column(db.Float)


# Database model for Comments
class Comment(db.Model):
    CommentID = db.Column(db.Integer, primary_key=True)
    NewsID = db.Column(db.Integer, db.ForeignKey('news.NewsID'))
    UserID = db.Column(db.Integer, db.ForeignKey('users.UserID'))
    Content = db.Column(db.Text)
    CommentDate = db.Column(db.DateTime, default=datetime.utcnow)


# Database model for UserPreferences
class UserPreference(db.Model):
    PreferenceID = db.Column(db.Integer, primary_key=True)
    UserID = db.Column(db.Integer, db.ForeignKey('users.UserID'))
    PreferenceType = db.Column(db.String(100))
    Value = db.Column(db.String(100))


# Database model for Categories
class Category(db.Model):
    CategoryID = db.Column(db.Integer, primary_key=True)
    Name = db.Column(db.String(100))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        favorite_sport = request.form['favoriteSport']

        hashed_password = generate_password_hash(password)

        new_user = Users(
            Username=username,
            Password=hashed_password,
            Email=email
        )

        db.session.add(new_user)
        db.session.commit()

        sport_preference = UserPreference(
            UserID=new_user.UserID,
            PreferenceType='FavoriteSport',
            Value=favorite_sport
        )

        db.session.add(sport_preference)
        db.session.commit()

        return redirect(url_for('homepage'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = Users.query.filter_by(Username=username).first()

        if user:
            if check_password_hash(user.Password, password):
                session['user_id'] = user.UserID
                return redirect(url_for('homepage'))
            else:
                return render_template('login.html', error="Password is incorrect, please re-enter.")
        else:
            return render_template('login.html', error="The account does not exist, please re-enter or register.")
    return render_template('login.html')



@app.route("/", methods=['GET'])
def index():
    return render_template('login.html')


@app.route('/homepage', methods=['GET'])
def homepage():


    image_file = 'image/Default.jpg'
    preference_title = 'Sports News'

    if 'user_id' in session:
        user_id = session['user_id']
        preference = UserPreference.query.filter_by(UserID=user_id, PreferenceType='FavoriteSport').first()
        if preference:
            sport_to_image = {
                'basketball': 'image/NBA.jpg',
                'baseball': 'image/Baseball.jpg',
                'rugby': 'image/Rugby.jpg'
            }
            image_file = sport_to_image.get(preference.Value.lower(), 'image/Default.jpg')
            preference_title = f"{preference.Value} News"

    news_data = fetch_news_data("sports")
    if not news_data:
        news_data = []


    return render_template("homepage.html", image_file=image_file, preference_title=preference_title, news_data=news_data)


# Choose your desired pre-trained model name (e.g., facebook/bart-base)
model_name = "distilbert-base-uncased-distilled-squad"

# # Load the pre-trained model
# model = AutoModelForQuestionAnswering.from_pretrained(model_name)

from bs4 import BeautifulSoup


def chatbot_response(url):

    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')

    title = soup.find('h1').get_text() if soup.find('h1') else "No title found"


    meta_description = soup.find('meta', attrs={'name': 'description'})
    description = meta_description['content'] if meta_description else 'No description found'


    paragraphs = soup.find_all('p')
    content = ' '.join(paragraph.get_text() for paragraph in paragraphs)


    combined_info = f"Title: {title}\nDescription: {description}\nContent: {content}"


    result = qa_pipeline(question="What can I do for you regarding the news item you've dragged in?",
                         context=combined_info)
    answer = result['answer']

    return {"answer": answer}


@app.route('/fetch-news-content', methods=['POST'])
def fetch_news_content():
    data = request.get_json()
    url = data.get("url")
    if not url:
        return jsonify({"error": "URL is required"}), 400

    try:
        response = requests.get(url)
        if response.status_code == 200:
            soup = BeautifulSoup(response.content, 'html.parser')
            title = soup.find('h1').get_text() if soup.find('h1') else "No title found"
            meta_description = soup.find('meta', attrs={'name': 'description'})
            description = meta_description['content'] if meta_description else 'No description found'
            paragraphs = soup.find_all('p')
            content = ' '.join(paragraph.get_text() for paragraph in paragraphs)
            return jsonify({"title": title, "description": description, "content": content})
        else:
            return jsonify({"error": "Failed to fetch content"}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/chatbot', methods=['GET', 'POST'])
def chatbot():
    # Initialize context (conversation history)
    context = ''
    # Ensure a context is maintained during the conversation
    if 'context' not in session:
        session['context'] = ''

    if request.method == "POST":
        data = request.get_json()
        news_url = data.get("url", "")
        session['context'] = context

        if news_url:
            try:
                response = requests.get(news_url)
                if response.status_code == 200:
                    soup = BeautifulSoup(response.content, 'html.parser')
                    title = soup.find('h1').get_text() if soup.find('h1') else "No title found"
                    paragraphs = soup.find_all('p')
                    content = ' '.join(paragraph.get_text() for paragraph in paragraphs)
                    # Add new information to the existing conversation context
                    context = f"{session['context']} {title} {content}"

                    result = qa_pipeline(question="What is the content about?", context=context)
                    answer = result['answer']

                    # Update conversation context in session
                    session['context'] = context
                else:
                    answer = "Failed to fetch content from the URL provided."
            except Exception as e:
                answer = f"An error occurred: {str(e)}"
        else:
            answer = "Due to model limitations, I can only tell you what this news is about for the time being."
    else:
        # For GET requests, reset conversation context
        session['context'] = ''
        return render_template('chatbot.html')

    return jsonify({"answer": answer})


def fetch_news_data(category, q=None):
    url = f"https://newsapi.org/v2/top-headlines?apiKey={api_key}&country=us&category={category}&pageSize=99&language=en"

    if q:
        url += f"&q={q}"
    print(f"Requesting URL: {url}")
    try:
        response = requests.get(url, timeout=30)
        print(f"API Response: {response.text}")
        if response.status_code == 200:
            data = response.json()
            if data['status'] == "ok":
                news_data = []
                for article in data['articles']:
                    news_data.append({
                        "title": article['title'],
                        "published_at": article['publishedAt'],
                        "source": article['source']['name'],
                        "image_url": article['urlToImage'],
                        "url": article['url'],
                    })
                return news_data
            else:
                print(f"API failed: {data.get('message', 'unknown')}")
        else:
            print(f"failed: {response.status_code}")
    except requests.exceptions.RequestException as e:
        print(f"request unknown: {e}")

    return []


@app.route('/baseball', methods=['GET'])
def baseball():
    news_data = fetch_news_data("sports", q="MLB")
    return render_template('baseball.html', news_data=news_data)


@app.route('/rugby', methods=['GET'])
def rugby():
    news_data = fetch_news_data("sports", q="NFL")
    return render_template('rugby.html', news_data=news_data)


@app.route('/others', methods=['GET'])
def others():
    news_data = fetch_news_data("health")
    return render_template('others.html', news_data=news_data)


@app.route('/basketball', methods=['GET'])
def basketball():

    news_data = fetch_news_data("sports", q="NBA")
    return render_template('basketball.html', news_data=news_data)


with app.app_context():
    db.create_all()

if __name__ == '__main__':
    FLASK_DEBUG = 1
    app.run(debug=True)
