import websocket
import json
import time
import logging
import urllib.parse

from config import (
    XUNFEI_APPID,
    XUNFEI_API_KEY,
    XUNFEI_API_SECRET,
    XUNFEI_API_URL,
    generate_xunfei_headers,
)

ws = None  # Declare ws variable globally
is_ws_connected = False


def on_open(ws):
    print("WebSocket connection opened")
    global is_ws_connected
    is_ws_connected = True


def on_close(ws, close_status_code, close_msg):
    print("WebSocket closed")
    global is_ws_connected
    is_ws_connected = False


def on_message(ws, message):
    print(f"Received a message from WS: {message}")
    data = json.loads(message)
    if data['header']['app_id'] != XUNFEI_APPID:
        print(f"Invalid app_id: {data['header']['app_id']}")
        return
    if data['header']['name'] != 'chat':
        print(f"Invalid header name: {data['header']['name']}")
        return
    user_input = data['payload']['message']['text'][0]['content']
    # ... Process user input ... (Replace this with your logic)
    bot_message = "I understand. It seems you're encountering an error. Please let me know if you have any further " \
                  "questions." # Replace with your bot's response
    # ... Generate bot reply ...
    response = {
        'header': {
            'app_id': XUNFEI_APPID,
        },
        'parameter': {
            'chat': {
                'domain': 'generalv3.5',
            }
        },
        'payload': {
            'message': {
                'text': [{'role': 'bot', 'content': bot_message}]
            }
        }
    }
    ws_response = ws.send(json.dumps(response))
    if ws_response is not None:
        print(f"Sent data to WS: {response}")
    else:
        print(f"Error sending data to WS.")


def on_error(ws, error):
    print(f"WebSocket encountered error: {error}")


def create_ws_connection():
    # 分解XUNFEI_API_URL以获取host和path
    url_parts = urllib.parse.urlparse(XUNFEI_API_URL)
    host = url_parts.hostname
    path = url_parts.path

    # 生成鉴权头
    headers = generate_xunfei_headers(host, path, XUNFEI_APPID, XUNFEI_API_KEY, XUNFEI_API_SECRET)

    # 创建查询字符串
    query_string = urllib.parse.urlencode({
        "authorization": headers['Authorization'],
        "date": headers['Date'],
        "host": host
    })

    # 生成最终的WebSocket URL
    final_url = f"wss://{host}{path}?{query_string}"

    # 使用最终的URL建立WebSocket连接
    ws = websocket.WebSocketApp(
        final_url,  # 使用含有鉴权信息的最终URL
        on_open=on_open,
        on_message=on_message,
        on_error=on_error,
        on_close=on_close,
        header=headers  # 这些是WebSocket的额外头部信息，如果需要的话
    )
    ws.run_forever(ping_interval=30, ping_timeout=10)
    logging.basicConfig(level=logging.DEBUG)  # Add logging
    print(final_url)
    print(headers)
    return ws


def check_and_connect_ws():
    global is_ws_connected, ws
    if ws is None or not ws.is_alive():
        ws = create_ws_connection()
        is_ws_connected = True  # Set to True after successful connection


def main():
    global ws
    check_and_connect_ws()  # Ensure initial connection

    while True:
        if not is_ws_connected:
            print("WebSocket connection lost. Reconnecting...")
            check_and_connect_ws()
            time.sleep(5)  # Reconnect interval
        else:
            time.sleep(1)  # Adjust loop interval


if __name__ == "__main__":
    main()

