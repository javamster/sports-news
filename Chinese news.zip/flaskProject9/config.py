import base64
import hashlib
import hmac
from datetime import datetime
from time import mktime
from wsgiref.handlers import format_date_time



def generate_xunfei_headers(host, path, app_id, api_key, api_secret):
    cur_time = datetime.now()
    date = format_date_time(mktime(cur_time.timetuple()))

    # 根据文档，这里的tmp需要更新
    tmp = f"host: {host}\ndate: {date}\nGET {path} HTTP/1.1"
    tmp_sha = hmac.new(api_secret.encode('utf-8'), tmp.encode('utf-8'), digestmod=hashlib.sha256).digest()
    signature = base64.b64encode(tmp_sha).decode('utf-8')

    # 更新authorization的格式
    authorization_origin = f"api_key='{api_key}', algorithm='hmac-sha256', headers='host date request-line', signature='{signature}'"
    authorization = base64.b64encode(authorization_origin.encode('utf-8')).decode('utf-8')

    return {
        'Content-Type': 'application/json',
        'Authorization': f"api_key=\"{api_key}\", algorithm=\"hmac-sha256\", headers=\"host date request-line\", signature=\"{signature}\"",
        'Date': date,
        'Host': host
    }

host = "spark-api.xf-yun.com"
path = "/v3.5/chat"  # 根据你提供的URL更新path
XUNFEI_API_URL = "wss://spark-api.xf-yun.com/v3.5/chat"
XUNFEI_APPID = "61da86ca"  # 你的实际应用ID
XUNFEI_API_KEY = "23c6c4cd9cd3e123b10b9181661631f"  # 你的实际API密钥
XUNFEI_API_SECRET = "ODIwNzJiNjk4ODk5MjVlYzRhMGY2OTI5"  # 你的实际API密钥
headers = generate_xunfei_headers(host, path, XUNFEI_APPID, XUNFEI_API_KEY, XUNFEI_API_SECRET)
print(headers)
