from jinja2.ext import Extension




class EmptyListCheck(Extension):
    def __init__(self, environment):
        super(EmptyListCheck, self).__init__(environment)
        environment.filters['is_empty'] = is_empty

def is_empty(list_obj):
    return len(list_obj) == 0



if __name__ == '__main__':
    FLASK_DEBUG = 0  # Set to 1 for development mode (optional)
    app.run()
