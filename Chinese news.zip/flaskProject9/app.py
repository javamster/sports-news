from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import requests
from custom_filters import EmptyListCheck
from transformers import AutoModelForQuestionAnswering, AutoTokenizer, pipeline

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:242568@localhost/SportsNewsDB'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
# Choose the correct pre-trained model
model_name = "distilbert-base-uncased-distilled-squad"
#Load the pre-trained model and tokenizer
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForQuestionAnswering.from_pretrained(model_name)

# Create a pipeline for question-answering
qa_pipeline = pipeline("question-answering", model=model, tokenizer=tokenizer)


class News(db.Model):
    NewsID = db.Column(db.Integer, primary_key=True)
    Title = db.Column(db.String(255))
    Content = db.Column(db.Text)
    Category = db.Column(db.String(100))
    PublishDate = db.Column(db.DateTime)
    Source = db.Column(db.String(255))
    Views = db.Column(db.Integer, default=0)


# Database model for Users
class Users(db.Model):
    UserID = db.Column(db.Integer, primary_key=True)
    Username = db.Column(db.String(100))
    Password = db.Column(db.String(1000))
    Email = db.Column(db.String(500))
    Role = db.Column(db.String(50))
    ProfilePic = db.Column(db.String(255))
    RegisteredDate = db.Column(db.DateTime, default=datetime.utcnow)


# Database model for ChatLogs
class ChatLog(db.Model):
    LogID = db.Column(db.Integer, primary_key=True)
    UserID = db.Column(db.Integer, db.ForeignKey('users.UserID'))
    Message = db.Column(db.Text)
    Timestamp = db.Column(db.DateTime, default=datetime.utcnow)


# Database model for UserRecommendations
class UserRecommendation(db.Model):
    RecommendationID = db.Column(db.Integer, primary_key=True)
    UserID = db.Column(db.Integer, db.ForeignKey('users.UserID'))
    NewsID = db.Column(db.Integer, db.ForeignKey('news.NewsID'))
    Score = db.Column(db.Float)


# Database model for Comments
class Comment(db.Model):
    CommentID = db.Column(db.Integer, primary_key=True)
    NewsID = db.Column(db.Integer, db.ForeignKey('news.NewsID'))
    UserID = db.Column(db.Integer, db.ForeignKey('users.UserID'))
    Content = db.Column(db.Text)
    CommentDate = db.Column(db.DateTime, default=datetime.utcnow)


# Database model for UserPreferences
class UserPreference(db.Model):
    PreferenceID = db.Column(db.Integer, primary_key=True)
    UserID = db.Column(db.Integer, db.ForeignKey('users.UserID'))
    PreferenceType = db.Column(db.String(100))
    Value = db.Column(db.String(100))


# Database model for Categories
class Category(db.Model):
    CategoryID = db.Column(db.Integer, primary_key=True)
    Name = db.Column(db.String(100))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        # Extract form data
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        favorite_sport = request.form['favoriteSport']

        # Hash the password for security
        hashed_password = generate_password_hash(password)

        # Create a new User instance
        new_user = Users(
            Username=username,
            Password=hashed_password,
            Email=email,
            # Assume 'Role', 'ProfilePic', 'RegisteredDate' have default values or not required
        )

        # Add new user to the database
        db.session.add(new_user)
        db.session.flush()  # Flush the session to assign an ID to new_user

        # Now create a UserPreference instance for the favorite sport
        sport_preference = UserPreference(
            UserID=new_user.UserID,
            PreferenceType='FavoriteSport',
            Value=favorite_sport
        )

        # Add the new UserPreference to the database
        db.session.add(sport_preference)
        db.session.commit()

        # Redirect to homepage after registration
        return redirect(url_for('homepage'))

    # Render the registration template if method is GET
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = Users.query.filter_by(Username=username).first()
        if user:
            if check_password_hash(user.Password, password):
                return redirect(url_for('homepage'))
            else:
                return render_template('login.html', error="Password is incorrect, please re-enter.")
        else:
            return render_template('login.html', error="The account does not exist, please re-enter or register.")
    return render_template('login.html')


@app.route("/", methods=['GET'])
def index():
    return render_template('login.html')






@app.route("/homepage", methods=['GET', 'POST'])
def homepage():
    url = "https://v.juhe.cn/toutiao/index"
    params = {
        "type": "tiyu",  # 调整为你要获取的新闻类别
        "key": "74b081ccc6e254b5c50b9025850c4887",  # 填入你申请的API Key
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        result = response.json()
        if result['error_code'] == 0:
            news_data = result['result']['data']
            return render_template("homepage.html", news_data=news_data, len=len)
    return render_template("homepage.html", news_data=[])



# Choose your desired pre-trained model name (e.g., facebook/bart-base)
model_name = "distilbert-base-uncased-distilled-squad"

# Load the pre-trained model
model = AutoModelForQuestionAnswering.from_pretrained(model_name)


# def chatbot_response(question, news_id):
#     # 基于用户正在阅读的新闻ID找到新闻内容
#     news_article = News.query.get(news_id)
#     if news_article:
#         context = news_article.Content
#     else:
#         return {"answer": "Sorry, I can't find the news article you're referring to."}
#
#     # 使用pipeline生成回答
#     result = qa_pipeline(question=question, context=context)
#     answer = result['answer']
#
#     return {"answer": answer}
def chatbot_response(question):
    # 手动设置的上下文
    context = "The 2022 FIFA World Cup is scheduled to take place in Qatar from 21 November to 18 December 2022."

    # 使用pipeline生成回答
    result = qa_pipeline(question=question, context=context)
    answer = result['answer']

    return {"answer": answer}


@app.route('/chatbot', methods=['GET', 'POST'])
def chatbot():
    if request.method == "POST":
        user_input = request.json.get("text")
        response = chatbot_response(user_input)
        return jsonify(response)
    else:
        return render_template('chatbot.html')


def fetch_news_data(tiyu):
    url = 'http://v.juhe.cn/toutiao/index'
    params = {
        "type": tiyu,  # 调整为你要获取的新闻类别
        "key": "74b081ccc6e254b5c50b9025850c4887",  # 填入你申请的API Key
    }
    response = requests.get(url, params=params)

    if response.status_code == 200:
        result = response.json()
        if result['error_code'] == 0:
            data = result['result']['data']
            return data
        else:
            print("请求失败:%s %s" % (result['error_code'], result['reason']))
    else:
        print("请求异常")
    return None


@app.route('/football', methods=['GET', 'POST'])
def football():
    news_data = fetch_news_data("football")
    return render_template('football.html')


@app.route('/basketball', methods=['GET', 'POST'])
def basketball():
    news_data = fetch_news_data("basketball")
    return render_template('basketball.html')


@app.route('/tennis', methods=['GET', 'POST'])
def tennis():
    news_data = fetch_news_data("tennis")
    return render_template('tennis.html')



with app.app_context():
    db.create_all()

if __name__ == '__main__':
    FLASK_DEBUG = 1
    app.run(debug=True)